# ProjetEtudiant

Installer Meteor : https://www.meteor.com/install

Une fois Meteor installé ouvrir un terminal a la racine du projet et faire : meteor add jquery

Pour lancer le projet ouvrir un terminal depuis la racine du projet et taper : meteor

Se rendre sur http://localhost:3000/ 
