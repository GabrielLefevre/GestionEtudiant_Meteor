/**
 * Created by Gabriel on 12/11/2015.
 */
Moyenne = new Mongo.Collection("moyenne");
